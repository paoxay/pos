<?php
require_once 'config.php';
checkLogin();

// Handle form submissions
if ($_POST) {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $stmt = $pdo->prepare("INSERT INTO products (barcode, name, stock, cost, price) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$_POST['barcode'], $_POST['name'], $_POST['stock'], $_POST['cost'], $_POST['price']]);
                $success = "เพิ่มสินค้าเรียบร้อย";
                break;
                
            case 'edit':
                $stmt = $pdo->prepare("UPDATE products SET barcode = ?, name = ?, stock = ?, cost = ?, price = ? WHERE id = ?");
                $stmt->execute([$_POST['barcode'], $_POST['name'], $_POST['stock'], $_POST['cost'], $_POST['price'], $_POST['id']]);
                $success = "แก้ไขสินค้าเรียบร้อย";
                break;
                
            case 'delete':
                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$_POST['id']]);
                $success = "ลบสินค้าเรียบร้อย";
                break;
        }
    }
}

// Get products
$stmt = $pdo->query("SELECT * FROM products ORDER BY name");
$products = $stmt->fetchAll();

// Get product for editing
$edit_product = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_product = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการสินค้า - ระบบขายเสื้อฝ้า</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Sarabun', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-blue-600 text-white shadow-lg">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-tshirt text-2xl"></i>
                    <h1 class="text-xl font-bold">ระบบขายเสื้อฝ้า</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="hover:text-blue-200">กลับหน้าหลัก</a>
                    <span class="text-sm"><?php echo $_SESSION['user_name']; ?></span>
                    <a href="logout.php" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                        <i class="fas fa-sign-out-alt mr-1"></i>ออกจากระบบ
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold">จัดการสินค้า</h2>
            <button onclick="showAddForm()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                <i class="fas fa-plus mr-2"></i>เพิ่มสินค้า
            </button>
        </div>

        <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Add/Edit Product Form -->
        <div id="productForm" class="bg-white p-6 rounded-lg shadow mb-6 <?php echo $edit_product ? '' : 'hidden'; ?>">
            <h3 class="text-lg font-semibold mb-4"><?php echo $edit_product ? 'แก้ไขสินค้า' : 'เพิ่มสินค้าใหม่'; ?></h3>
            <form method="POST">
                <input type="hidden" name="action" value="<?php echo $edit_product ? 'edit' : 'add'; ?>">
                <?php if ($edit_product): ?>
                    <input type="hidden" name="id" value="<?php echo $edit_product['id']; ?>">
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">รหัสบาร์โค้ด</label>
                        <input type="text" name="barcode" value="<?php echo $edit_product['barcode'] ?? ''; ?>" class="w-full p-3 border rounded-lg" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">ชื่อสินค้า</label>
                        <input type="text" name="name" value="<?php echo $edit_product['name'] ?? ''; ?>" class="w-full p-3 border rounded-lg" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">จำนวนสต็อก</label>
                        <input type="number" name="stock" value="<?php echo $edit_product['stock'] ?? ''; ?>" class="w-full p-3 border rounded-lg" min="0" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">ต้นทุน (บาท)</label>
                        <input type="number" name="cost" value="<?php echo $edit_product['cost'] ?? ''; ?>" class="w-full p-3 border rounded-lg" min="0" step="0.01" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">ราคาขาย (บาท)</label>
                        <input type="number" name="price" value="<?php echo $edit_product['price'] ?? ''; ?>" class="w-full p-3 border rounded-lg" min="0" step="0.01" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">กำไร (บาท)</label>
                        <input type="text" id="profitDisplay" class="w-full p-3 border rounded-lg bg-gray-100" readonly>
                    </div>
                </div>
                <div class="flex space-x-4 mt-6">
                    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                        <i class="fas fa-save mr-2"></i>บันทึก
                    </button>
                    <button type="button" onclick="hideForm()" class="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600">
                        ยกเลิก
                    </button>
                </div>
            </form>
        </div>

        <!-- Products Table -->
        <div class="bg-white rounded-lg shadow">
            <div class="p-6">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="border-b">
                                <th class="text-left py-2">บาร์โค้ด</th>
                                <th class="text-left py-2">ชื่อสินค้า</th>
                                <th class="text-left py-2">สต็อก</th>
                                <th class="text-left py-2">ต้นทุน</th>
                                <th class="text-left py-2">ราคาขาย</th>
                                <th class="text-left py-2">กำไร</th>
                                <th class="text-left py-2">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($products)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-8 text-gray-500">ยังไม่มีสินค้า</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($products as $product): ?>
                                    <?php $profit = $product['price'] - $product['cost']; ?>
                                    <tr>
                                        <td class="py-2"><?php echo $product['barcode']; ?></td>
                                        <td class="py-2"><?php echo $product['name']; ?></td>
                                        <td class="py-2"><?php echo $product['stock']; ?></td>
                                        <td class="py-2"><?php echo number_format($product['cost'], 2); ?> บาท</td>
                                        <td class="py-2"><?php echo number_format($product['price'], 2); ?> บาท</td>
                                        <td class="py-2 <?php echo $profit > 0 ? 'text-green-600' : 'text-red-600'; ?>">
                                            <?php echo number_format($profit, 2); ?> บาท
                                        </td>
                                        <td class="py-2">
                                            <a href="?edit=<?php echo $product['id']; ?>" class="text-blue-600 hover:text-blue-800 mr-2">
                                                <i class="fas fa-edit"></i> แก้ไข
                                            </a>
                                            <form method="POST" class="inline" onsubmit="return confirm('คุณต้องการลบสินค้านี้หรือไม่?')">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                                <button type="submit" class="text-red-600 hover:text-red-800">
                                                    <i class="fas fa-trash"></i> ลบ
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showAddForm() {
            document.getElementById('productForm').classList.remove('hidden');
            document.querySelector('form').reset();
            document.querySelector('input[name="action"]').value = 'add';
            document.querySelector('h3').textContent = 'เพิ่มสินค้าใหม่';
        }

        function hideForm() {
            document.getElementById('productForm').classList.add('hidden');
        }

        // Calculate profit
        function calculateProfit() {
            const cost = parseFloat(document.querySelector('input[name="cost"]').value) || 0;
            const price = parseFloat(document.querySelector('input[name="price"]').value) || 0;
            document.getElementById('profitDisplay').value = (price - cost).toFixed(2);
        }

        document.querySelector('input[name="cost"]').addEventListener('input', calculateProfit);
        document.querySelector('input[name="price"]').addEventListener('input', calculateProfit);

        // Calculate initial profit if editing
        <?php if ($edit_product): ?>
            calculateProfit();
        <?php endif; ?>
    </script>
</body>
</html>
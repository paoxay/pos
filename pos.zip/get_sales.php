<?php
require_once 'config.php';
checkLogin();

header('Content-Type: application/json');

try {
    $date = $_GET['date'] ?? date('Y-m-d');
    
    // ดึงข้อมูลการขายตามวันที่
    $stmt = $pdo->prepare("
        SELECT 
            s.id,
            s.sale_date,
            s.subtotal,
            s.discount,
            s.total,
            s.profit,
            COUNT(si.id) as item_count
        FROM sales s 
        LEFT JOIN sale_items si ON s.id = si.sale_id 
        WHERE DATE(s.sale_date) = ?
        GROUP BY s.id
        ORDER BY s.sale_date DESC
    ");
    
    $stmt->execute([$date]);
    $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($sales);
    
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
